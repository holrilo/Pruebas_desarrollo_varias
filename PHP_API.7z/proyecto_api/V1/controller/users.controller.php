<?php
require_once 'php/config/configconDB.php';
require_once 'v1/model/dao/usersDao.php';
require_once 'V1/model/users.php';

// echo "<br>";
// echo "entro";





// echo json_encode($model->selectAll());

// function imprime_pruebas(){
//     $model = new UsersDao();
//     echo json_encode($model->selectAllPDO());
// }

// function imprimeget(){
//     echo $opc=$_GET['user'];
// }


// echo "<br>";
// echo "<br>";
// include 'php/config/test_con_db.php';

class UsersController{
    public function __construct(){
        $this->model = new UsersDao();
    }

    public function seleccionar($id){
        if ($id !="") {
            return $this->model->selectIdPDO($id);
            // echo "no esta basi";
        }else {
            // echo json_encode($this->model->selectAllPDO());
            return $this->model->selectAllPDO();
        }
    }

    public function leerPostUser1($jsonPost){
        $user = new Users();
        $params = json_decode($jsonPost);
        if(isset($params->user))
            $user->setUser($params->user);
        if(isset($params->name_1))
            $user->setName_1($params->name_1);
        if(isset($params->name_2))
            $user->setName_2($params->name_2);
        if(isset($params->email))
            $user->setEmail($params->email);
        if(isset($params->phone))
            $user->setPhone($params->phone);
        if(isset($params->id))
            $user->setId($params->id);
        return $user;

    }

    public function leerPostUser($jsonPost){
        
        if($jsonPost != NULL){
            $_POST = $jsonPost;
        }
        
        $user = new Users();
        // $params = json_decode($jsonPost);


        if(isset($_POST["user"]))
            $user->setUser($_POST["user"]);
        if(isset($_POST["name_1"]))
            $user->setName_1($_POST["name_1"]);
        if(isset($_POST["name_2"]))
            $user->setName_2($_POST["name_2"]);
        if(isset($_POST["email"]))
            $user->setEmail($_POST["email"]);
        if(isset($_POST["phone"]))
            $user->setPhone($_POST["phone"]);
        if(isset($_POST["id"]))
            $user->setId($_POST["id"]);
        // VAR_DUMp( $_POST);
        // echo $_POST["user"];

        return $user;

    }
    public function insertar($json){
        // $params = json_decode($json); // DECODIFICA EL JSON Y LO GUARADA EN LA VARIABLE

        // echo json_encode($params);
        // echo $params->user;
        $user = $this->leerPostUser1($json);
        // $user = new Users();
        // echo $user->getUser();
        $resultado = $this->model->insert($user);
        return $resultado;
    }

    public function editar($json){
        // $params = json_decode($json); // DECODIFICA EL JSON Y LO GUARADA EN LA VARIABLE
        $user = $this->leerPostUser1($json);
        $resultado = $this->model->update($user);
        return $resultado; 
    }

    public function eliminar($id){
        $resultado = $this->model->delete($id);
        return $resultado;
    }
}

?>