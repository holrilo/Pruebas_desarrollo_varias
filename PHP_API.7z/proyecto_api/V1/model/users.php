<?php
class Users implements JsonSerializable{
    private $id;
    private $user;
    private $name_1;
    private $name_2;
    private $email;
    private $phone;
    
    function __construct() {
        
    }

    function crear($id,$user,$name_1,$name_2,$email,$phone){
        $this->id = $id;
        $this->user = $user;
        $this->name_1 = $name_1;
        $this->name_2 = $name_2;
        $this->email = $email;
        $this->phone = $phone;
    }

    

    /**
     * Get the value of id
     */ 
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set the value of id
     *
     * @return  self
     */ 
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * Get the value of user
     */ 
    public function getUser()
    {
        return $this->user;
    }

    /**
     * Set the value of user
     *
     * @return  self
     */ 
    public function setUser($user)
    {
        $this->user = $user;

        return $this;
    }

    /**
     * Get the value of name_1
     */ 
    public function getName_1()
    {
        return $this->name_1;
    }

    /**
     * Set the value of name_1
     *
     * @return  self
     */ 
    public function setName_1($name_1)
    {
        $this->name_1 = $name_1;

        return $this;
    }

    /**
     * Get the value of name_2
     */ 
    public function getName_2()
    {
        return $this->name_2;
    }

    /**
     * Set the value of name_2
     *
     * @return  self
     */ 
    public function setName_2($name_2)
    {
        $this->name_2 = $name_2;

        return $this;
    }

    /**
     * Get the value of email
     */ 
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * Set the value of email
     *
     * @return  self
     */ 
    public function setEmail($email)
    {
        $this->email = $email;

        return $this;
    }

    /**
     * Get the value of phone
     */ 
    public function getPhone()
    {
        return $this->phone;
    }

    /**
     * Set the value of phone
     *
     * @return  self
     */ 
    public function setPhone($phone)
    {
        $this->phone = $phone;

        return $this;
    }

    public function jsonSerialize() {
        $vars = get_object_vars($this);
        return $vars;
    }
}
?>