<?php
class UsersDao {
    
    function __construct()
    {
        $this->dbcon = new configconDB();
    }

    public function selectAllmysqli(){
        $stmt = $this->dbcon->con_db->prepare("SELECT * FROM tb_users");
        $stmt->execute();
        // $rows = $stmt->fetch_object();
        // $rows1= $rows->fetch_array(MYSQLI_BOTH);
        // $rows1= $rows->fetch_object(MYSQLI_ASSOC);
        
        // $usuarios = array();
        // while ($tDatos= $rows->fetch_object()) {
            
        //     $users = new Users();
        //     $users->crear($tDatos->id , $tDatos->user,$tDatos->name_1,$tDatos->name_2,$tDatos->email,$tDatos->phone);
        //     array_push($usuarios,$users);
        // }
        // foreach ($rows1 as $tDatos) {
        //     # code...
        //     $users = new Users();
        //     $users->crear($rows1->id , $tDatos->user,$tDatos->name_1,$tDatos->name_2,$tDatos->email,$tDatos->phone);
        //     array_push($usuarios,$users);
        //     // var_dump($rows1);
        //     // $tablaDatos[] = $tDatos;
        // }

        // $rows=$stmt->get_result();
        $rows =$stmt->bind_result($columns['id'], $columns['user'], $columns['name_1'], $columns['name_2'], $columns['email'], $columns['phone']);
        while ($tDatos=$stmt->fetch()) {
            // $tablaDatos[] = $tDatos;
            // $users->crear($rows1->id , $tDatos->user,$tDatos->name_1,$tDatos->name_2,$tDatos->email,$tDatos->phone);
            $tDatos = (object) $columns;
            $users = new Users();
            $users->crear($tDatos->id , $tDatos->user,$tDatos->name_1,$tDatos->name_2,$tDatos->email,$tDatos->phone);
        }
        return $tDatos;
    }

    public function selectAllPDO(){
        $users = array();
        $stmt= $this->dbcon->conn_db->prepare("SELECT * FROM tb_users  ");
        $stmt->execute();
        $tDato = $stmt->fetchAll(PDO::FETCH_OBJ);
        if ($tDato != null) {
            // $profesor = new Profesor();
            // $profesor->crear($p->correo, $p->nombre, $p->apellidos, $p->telefono, $p->clave, $p->imagenAvatar);
            
            foreach($tDato as  $tDatos)
            {
                
            $user = new Users();
            $user->crear($tDatos->id , $tDatos->user,$tDatos->name_1,$tDatos->name_2,$tDatos->email,$tDatos->phone);
            // $res = $user;   
            array_push($users,$user);
        }
        } else {
            $users = null;
        }
        return $users;


    }
    public function selectIdPDO($id){
        $users = array();
        $stmt= $this->dbcon->conn_db->prepare("SELECT * FROM tb_users where id = :id ");
        $stmt->bindParam(':id',$id);
        $stmt->execute();
        $tDato = $stmt->fetchAll(PDO::FETCH_OBJ);
        if ($tDato != null) {
            // $profesor = new Profesor();
            // $profesor->crear($p->correo, $p->nombre, $p->apellidos, $p->telefono, $p->clave, $p->imagenAvatar);
            
            foreach($tDato as  $tDatos)
            {
                
            $user = new Users();
            $user->crear($tDatos->id , $tDatos->user,$tDatos->name_1,$tDatos->name_2,$tDatos->email,$tDatos->phone);
            // $res = $user;   
            array_push($users,$user);
        }
        } else {
            $users = null;
        }
        return $users;


    }

    Public function insert(Users $data){
        $stmt = $this->dbcon->conn_db->prepare(
            "INSERT INTO tb_users( user, name_1, name_2, email, phone) 
             VALUES (?, ?, ?, ?, ?)"
        );
        // $stmt->bindParam([$data->getUser(),$data->getName_1(),$data->getName_2(),$data->getEmail(),$data->getPhone()]);
        $stmt->execute([$data->getUser(),$data->getName_1(),$data->getName_2(),$data->getEmail(),$data->getPhone()]);
        // $stmt->execute();

    }

    public function update(Users $data){
        $stmt = $this->dbcon->conn_db->prepare(
            "UPDATE tb_users SET
                user = ifnull(:user,user),
                name_1 = ifnull(:name_1,name_1),
                name_2 = ifnull(:name_2,name_2),
                email = ifnull(:email,email),
                phone = ifnull(:phone,phone)  
            WHERE id = :id
            "
        );
        $stmt->bindValue(':user',$data->getUser(),PDO::PARAM_STR);
        $stmt->bindValue(':name_1',$data->getName_1(),PDO::PARAM_STR);
        $stmt->bindValue(':name_2',$data->getName_2(),PDO::PARAM_STR);
        $stmt->bindValue(':email',$data->getEmail(),PDO::PARAM_STR);
        $stmt->bindValue(':phone',$data->getPhone(),PDO::PARAM_STR);
        $stmt->bindValue(':id',$data->getId(),PDO::PARAM_STR);
        $stmt->execute();
    }

    public function delete($id){
        $stmt= $this->dbcon->conn_db->prepare(
            "DELETE FROM tb_users WHERE id = ?"
        );
        $stmt->execute(array($id));
    }
}
?>