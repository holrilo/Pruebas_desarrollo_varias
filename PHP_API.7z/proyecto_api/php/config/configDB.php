<?php
class configDB
{
    /** ==================== Produccion ==================== */
        // protected $host_name = "";
        // protected $user_name = "";
        // protected $password = "";
        // protected $db_name = "";
    /** ==================================================== */

    /** ==================== Desarrollo ==================== */
        protected $host_name = "localhost";
        protected $user_name = "root";
        protected $password = "";
        protected $db_name = "pruebas_api";
    /** ==================================================== */

    /** ==================== Pruebas Usuario ==================== */
        // protected $host_name = "";
        // protected $user_name = "";
        // protected $password = "";
        // protected $db_name = "";
    /** ==================================================== */    
}
?>