<?php
$url = $_SERVER['SERVER_NAME'];
define('PROJECT_ROOT_PATH', 'https://' . $url . '/proyecto_api/');
define('LOG_PATH', $_SERVER['DOCUMENT_ROOT'],'/proyecto_api/log/');
?>