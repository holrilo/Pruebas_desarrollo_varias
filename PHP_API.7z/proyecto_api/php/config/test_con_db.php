<?php 
// include 'configconDB.php';

$dbcon = new configconDB();
// $dbcon->test_con_db();
$dbcon->test_con_db_PDO();
?>