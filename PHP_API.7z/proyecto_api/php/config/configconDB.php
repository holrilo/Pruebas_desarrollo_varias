<?php
require_once 'configDB.php';

class configconDB extends configDB{
    
    function __construct(){
        // $this->con_mysqli();
        $this->con_PDO();
    }

    public function con_mysqli(){
        $this->con_db = new mysqli($this->host_name, $this->user_name, $this->password, $this->db_name);
    }
    public function con_PDO(){
        try {
            $this->conn_db = new PDO("mysql:host=$this->host_name;dbname=$this->db_name",$this->user_name, $this->password);
            $this->conn_db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            // echo "La conexión fue exitosa Connect Successfully. Host info: " . $this->conn_db->host_info;
            // die(json_encode(array('outcome' => true)));
        } catch (PDOExeption $e) {
            //throw $th;
            die("Error en la conexion: " .  $e->getMessage());
            // die(json_encode(array('outcome' => false, 'message' => 'Unable to connect')));
        }
    }
    public function test_con_db(){
        if ($this->con_db->connect_errno) {
            # code...
            die("Error en la conexion: " . $this->con_db->connect_errno);
        }else
        echo "La conexión fue exitosa Connect Successfully. Host info: " . $this->con_db->host_info;
    }

    public function test_con_db_PDO(){
    
            }
    
}

?>