<?php
/**
 * permito el acceso a recursos desde un origen distinto
 * habilito los metodos get, post, put y delete
 */

header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
// header("Allow: GET, POST, OPTIONS, PUT, DELETE");

$method = $_SERVER['REQUEST_METHOD'];
$url = $_SERVER['REQUEST_URI'];
ECHO $url;

//echo $method;
switch ($method) {
    case 'GET':
        # code...
        echo "Ingreso metodo al metodo GET V1 <br> ";

        include 'php/config/test_con_db.php';
        break;
    case 'POST':
        # code...
        echo "Ingreso metodo al metodo POST";
        break;
    case 'PUT':
        # code...
        echo "Ingreso metodo al metodo PUT";
        break;
    case 'DELETE':
        # code...
        echo "Ingreso metodo al metodo DELETE";
        break;
    default:
        # code...
        echo "Ingreso metodo desconocido";
        break;
}


?>