<?php 
require_once 'php/config/configconDB.php';
require_once 'v2/model/dao/usersDao.php';
require_once 'V2/model/users.php';

Class UsersController{
    public function __construct(){
        $this->model = new UsersDao();
    }

    public function seleccionar($id){
        if ($id !="") {
            // return $this->model->selectIdPDO($id);
        }else {
            return $this->model->selectAllPDO();
        }
    }
}
?>