<?php 
class Users implements JsonSerializable{

    private $id_users;
    private $nombre_users;
    private $apellidos_users;
    private $usuario_users;
    private $clave_users;
    private $fecha_crear;
    private $cedula_users;
    private $email_users;
    private $estado_users;

    function __construct() {
        
    }

    function crear($id_users,$nombre_users,$apellidos_users,$usuario_users,$clave_users,$fecha_crear,$cedula_users,$email_users,$estado_users){
        
        $this->id_users = $id_users;
        $this->nombre_users = $nombre_users;
        $this->apellidos_users = $apellidos_users;
        $this->usuario_users = $usuario_users;
        $this->clave_users = $clave_users;
        $this->fecha_crear = $fecha_crear;
        $this->cedula_users = $cedula_users;
        $this->email_users = $email_users;
        $this->estado_users = $estado_users;
    }


    /**
     * Get the value of id_users
     */ 
    public function getId_users()
    {
        return $this->id_users;
    }

    /**
     * Set the value of id_users
     *
     * @return  self
     */ 
    public function setId_users($id_users)
    {
        $this->id_users = $id_users;

        return $this;
    }

    /**
     * Get the value of nombre_users
     */ 
    public function getNombre_users()
    {
        return $this->nombre_users;
    }

    /**
     * Set the value of nombre_users
     *
     * @return  self
     */ 
    public function setNombre_users($nombre_users)
    {
        $this->nombre_users = $nombre_users;

        return $this;
    }

    /**
     * Get the value of apellidos_users
     */ 
    public function getApellidos_users()
    {
        return $this->apellidos_users;
    }

    /**
     * Set the value of apellidos_users
     *
     * @return  self
     */ 
    public function setApellidos_users($apellidos_users)
    {
        $this->apellidos_users = $apellidos_users;

        return $this;
    }

    /**
     * Get the value of usuario_users
     */ 
    public function getUsuario_users()
    {
        return $this->usuario_users;
    }

    /**
     * Set the value of usuario_users
     *
     * @return  self
     */ 
    public function setUsuario_users($usuario_users)
    {
        $this->usuario_users = $usuario_users;

        return $this;
    }

    /**
     * Get the value of clave_users
     */ 
    public function getClave_users()
    {
        return $this->clave_users;
    }

    /**
     * Set the value of clave_users
     *
     * @return  self
     */ 
    public function setClave_users($clave_users)
    {
        $this->clave_users = $clave_users;

        return $this;
    }

    /**
     * Get the value of fecha_crear
     */ 
    public function getFecha_crear()
    {
        return $this->fecha_crear;
    }

    /**
     * Set the value of fecha_crear
     *
     * @return  self
     */ 
    public function setFecha_crear($fecha_crear)
    {
        $this->fecha_crear = $fecha_crear;

        return $this;
    }

    /**
     * Get the value of cedula_users
     */ 
    public function getCedula_users()
    {
        return $this->cedula_users;
    }

    /**
     * Set the value of cedula_users
     *
     * @return  self
     */ 
    public function setCedula_users($cedula_users)
    {
        $this->cedula_users = $cedula_users;

        return $this;
    }

    /**
     * Get the value of email_users
     */ 
    public function getEmail_users()
    {
        return $this->email_users;
    }

    /**
     * Set the value of email_users
     *
     * @return  self
     */ 
    public function setEmail_users($email_users)
    {
        $this->email_users = $email_users;

        return $this;
    }

    /**
     * Get the value of estado_users
     */ 
    public function getEstado_users()
    {
        return $this->estado_users;
    }

    /**
     * Set the value of estado_users
     *
     * @return  self
     */ 
    public function setEstado_users($estado_users)
    {
        $this->estado_users = $estado_users;

        return $this;
    }

    public function jsonSerialize() {
        $vars = get_object_vars($this);
        return $vars;
    }
}
?>