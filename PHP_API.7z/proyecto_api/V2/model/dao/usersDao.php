<?php 
Class UsersDao{

    function __construct()
    {
        $this->dbcon = new configconDB();
    }

    public function selectAllPDO(){
        $users = array();
        $stmt = $this->dbcon->conn_db->prepare("SELECT * FROM usuarios;");
        $stmt->execute();
        $tDato = $stmt->fetchAll(PDO::FETCH_OBJ);
        // echo  $tDato;
        if ($tDato != null) {
            foreach ($tDato as $tDatos) {
                $user = new Users();
                $user->crear($tDatos->id_users,
                            $tDatos->nombre_users,
                            $tDatos->apellidos_users,
                            $tDatos->usuario_users,
                            $tDatos->clave_users,
                            $tDatos->fecha_crear,
                            $tDatos->cedula_users,
                            $tDatos->email_users,
                            $tDatos->estado_users);
                            array_push($users,$user);
                            // var_dump($tDatos);
                
            }
        }else {
            $users = null;
        }
        
        return $users;
        
    }
}


?>