<?php
/**
 * permito el acceso a recursos desde un origen distinto
 * habilito los metodos get, post, put y delete
 */

header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
// header("Allow: GET, POST, OPTIONS, PUT, DELETE");


/**
 * [1] - Carpeta proyecto
 * [2] - Version
 * [3] - Controller 
 * [4] - Accion 
 * [5] - Parametro 
 */


$method = $_SERVER['REQUEST_METHOD'];
$url = $_SERVER['REQUEST_URI'];
$url_arry = explode("/", $url);

// ECHO $url;
// ECHO "<br>";
// var_dump( $url_arry);
// echo "<br>";

// echo "<br>";
// echo $url_arry[2], '/controller/',$url_arry[3],'.controller.php';
// echo "<br>";

// echo $controller;
// echo "<br>";

// if(empty($_GET)){
//     imprimeError("401", "get vacio");
// }else
// imprimeError("401", "get no vacio");
// echo $url_arry[2] . '/controller/'. $url_arry[3] .'.controller.php';
// Validacion De la version del WS
if (!file_exists ($url_arry[2])) {
    // echo "no existe servicio";
    // echo  $url_arry[2] , file_exists ($url_arry[2]) ?  " => Ws Existe" : " => Ws No Existe" ;
    $msj =  $url_arry[2] . (file_exists ($url_arry[2]) ?  " => Ws Existe" : " => Ws No Existe") ;
    imprimeError("401", $msj);
}else{
    //Crea ruta de controller 
    $controller = $url_arry[2] . '/controller/' .$url_arry[3] . '.controller.php';
    if (!file_exists($controller)) {
        // echo "no existe servicio";
        // echo $url_arry[3] , file_exists ($controller) ?  " => Controlador Existe" : " => Controlador No Existe" ;
        $msj = $url_arry[3] . (file_exists ($controller) ?  " => Controlador Existe" : " => Controlador No Existe") ;
        imprimeError("401", $msj);
    }else{
        //ejecuta controlador 
        // require_once  $url_arry[2] . '/controller/users.controller.php';
        require_once  $url_arry[2] . '/controller/'. $url_arry[3] .'.controller.php';
        $controller = ucwords($url_arry[3]) . "Controller";
        $control = new $controller(null);
       
        // $id = "";
        if(!empty($_GET)){
            if(!isset($id)){$id= $_GET['id'];}
        }else{
            $id = '';
        }

        // $parametro = "pruebas";
        // ${"pruebas"}=1;
        // echo $pruebas; 

        switch ($method) {
            case 'GET':
                // echo "Ingreso metodo al metodo GET V1 <br> ";
                // include 'php/config/test_con_db.php';
                
                // if(!empty($_GET)){
                //     // imprimeError("401", "get vacio");
                //     // imprime_pruebas();
                //     // echo $opc=$_GET['user'];
                //     resultadoJson($control->seleccionar($id));
                // }else{
                //     // imprimeError("401", "get no vacio");
                //     // imprimeget();
                    
                //     resultadoJson($control->seleccionar($id)) ;
                // }
                // resultadoJson($control->seleccionar($id));
                // echo $control;
                !is_null($control->seleccionar($id)) ? resultadoJson($control->seleccionar($id)) : imprimeError("200", "No hay registros para mostrar");

                // if (!function_exists('imprime_pruebas')) {
                //     # code...
                //     imprimeError("401", "la accion no existe");
                // }else{
                //     echo imprime_pruebas();
                // }
                break;
            case 'POST':
                # code...
                // echo "Ingreso metodo al metodo POST";
                $json = file_get_contents('php://input'); // RECIBE EL JSON 
                // $params = json_decode($json); // DECODIFICA EL JSON Y LO GUARADA EN LA VARIABLE
                // echo var_dump($params);
                $control->insertar($json);
                break;
            case 'PUT':
                # code...
                # RECIVIR JSON Y PASARLO COMPLETO CON JSDECODE 
                $json = file_get_contents('php://input'); // RECIBE EL JSON 
                $control->editar($json);

                # RECIVIR JSON Y PASARLO COMO ARRAY PARA EL POST
                // $json = file_get_contents('php://input'); // RECIBE EL JSON 
                // parse_str( $json,$postData);
                // $control->editar($postData);
                // var_dump($postData);
                
                // echo "Ingreso metodo al metodo PUT";
                break;
            case 'DELETE':
                # code...
                // echo "Ingreso metodo al metodo DELETE";
                $control->eliminar($id);
                break;
            default:
                # code...
                echo "Ingreso metodo desconocido";
                break;
        }
    }
    
}

function imprimeError($error, $mensaje){
    $responseError = array(
        "error" => $error,
        "mensaje" => $mensaje,
    );
    echo json_encode($responseError);
}

function resultadoJson($resultado){
    echo json_encode($resultado);
}




?>