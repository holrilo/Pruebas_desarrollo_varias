<?php

require_once "connection.php";

class GetModel{

/**
 * Peticiones Get sin Filtro 
 */
    static public function getData($table, $select,$orderBy,$orderMode,$startAt,$endAt){
        /**
         * VAlidar Existencia e la table y de las columnas 
         */
        $selectArray =  explode(",",$select);

        // echo '<pre>'; print_r(Connection::getColumnsData($table, $selectArray)); echo '</pre>';

        // return;

        if(empty(Connection::getColumnsData($table, $selectArray))){
            
            return null;
        }
        
        /**
         * Sin ordenar y limitar datos
         */
        $sql = "SELECT $select FROM $table ; ";
        // $sql = "SELECT * FROM $table ; ";

        /**
         * Ordenar Datos sin limites
         */
        if ($orderBy != null && $orderMode != null && $startAt == null && $endAt == null) {
            $sql = "SELECT $select FROM $table ORDER BY $orderBy $orderMode; ";
        }

        /**
         * Ordenar y limitar datos 
         */
        if ($orderBy != null && $orderMode != null && $startAt != null && $endAt != null) {
            $sql = "SELECT $select FROM $table ORDER BY $orderBy $orderMode LIMIT $startAt,$endAt ; ";
        }
        /**
         * Limitar datos sin Ordenar 
         */
        if ($orderBy == null && $orderMode == null && $startAt != null && $endAt != null) {
            $sql = "SELECT $select FROM $table ORDER BY $orderBy $orderMode LIMIT $startAt,$endAt ; ";
        }

        $stmt = Connection::connect()->prepare($sql);
        try {
            $stmt->execute();        
        } catch (PDOException $Exeption) {
            //throw $th;
            return null;
        }
        return $stmt -> fetchAll(PDO::FETCH_CLASS);

    }

/**
 * Peticiones Get Con Filtro 
 */

    static public function getDataFilter($table, $select, $linkTo, $equalTo,$orderBy,$orderMode,$startAt,$endAt){

        /**
         * VAlidar Existencia e la table 
         */
        $linkToArray = explode(",",$linkTo);
        $selectArray =  explode(",",$select);
        
        
        foreach ($linkToArray as $key => $value) {
            array_push($selectArray,$value) ;
        }
        
        $selectArray = array_unique($selectArray);
        // echo '<pre>'; print_r($selectArray); echo '</pre>';
        // return;

        if(empty(Connection::getColumnsData($table,$selectArray))){
            return null;
        }
        // $linkTo = "";
        // $linkToArray = explode(",",$linkTo);
        // $equalTo = "";
        $equalToArray = explode(",",$equalTo);
        $linkToText= "";

        if (count($linkToArray)>1) {
            foreach ($linkToArray as $key => $value) {
                if ($key > 0) {
                    $linkToText .= "AND " .$value." = :".$value." ";
                }
            }
        }

        // return;

        // $sql = "SELECT $select FROM $table WHERE $linkTo = :$linkTo ; ";
        /**
        * Sin ordenar y limitar datos
        */
        $sql = "SELECT $select FROM $table WHERE $linkToArray[0] = :$linkToArray[0] $linkToText ";
        // $sql = "SELECT * FROM $table ; ";
        
        /**
        * Ordenar Datos sin limites
        */
        if ($orderBy != null && $orderMode != null  && $startAt == null && $endAt == null) {
            $sql = "SELECT $select FROM $table WHERE $linkToArray[0] = :$linkToArray[0] $linkToText  ORDER BY $orderBy $orderMode; ";
        }
        /**
         * Ordenar y limitar datos 
         */
        if ($orderBy != null && $orderMode != null && $startAt != null && $endAt != null) {
            $sql = "SELECT $select FROM $table WHERE $linkToArray[0] = :$linkToArray[0] $linkToText  ORDER BY $orderBy $orderMode LIMIT $startAt,$endAt ; ";
        }
        /**
         * Limitar datos sin Ordenar 
         */
        if ($orderBy == null && $orderMode == null && $startAt != null && $endAt != null) {
            $sql = "SELECT $select FROM $table WHERE $linkToArray[0] = :$linkToArray[0] $linkToText  ORDER BY $orderBy $orderMode LIMIT $startAt,$endAt ; ";
        }

        $stmt = Connection::connect()->prepare($sql);
        foreach ($linkToArray as $key => $value) 
        {
            $stmt -> bindParam(":".$value,$equalToArray[$key], PDO::PARAM_STR);    
        }
        // $stmt -> bindParam(":".$linkTo,$equalTo, PDO::PARAM_STR);
    
        try {
            $stmt->execute();        
        } catch (PDOException $Exeption) {
            //throw $th;
            return null;
        }
        return $stmt -> fetchAll(PDO::FETCH_CLASS);

    }

/**
 * Peticiones Get sin Filtro con tablas relacionadas
 */
static public function getRelData($rel, $type, $select,$orderBy,$orderMode,$startAt,$endAt){
    
    $relArray = explode(",",$rel);
    $typeArray = explode(",",$type);

    $innerJoinText= "";

    if (count($relArray)>1) {
        foreach ($relArray as $key => $value) {
            /**
             * VAlidar Existencia de la table y de las columnas 
             */
            if(empty(Connection::getColumnsData($value,["*"]))){
                // if(empty(Connection::getColumnsData($value, $selectArray))){
                return null;
            }


            if ($key > 0) {
                $innerJoinText .= " INNER JOIN ".$value." ON ".$relArray[0].".".$typeArray[$key]." = ".$value.".".$typeArray[$key]." ";
            }
        }
    


        // "SELECT $select FROM $relArray[0] INNER JOIN $relArray[1] ON $relArray[0].$typeArray[0] = $relArray[1].$typeArray[1]";
        "SELECT $select FROM $relArray[0] $innerJoinText";
        
        /**
         * Sin ordenar y limitar datos
         */
        $sql = "SELECT $select FROM $relArray[0] $innerJoinText ; ";
        // $sql = "SELECT * FROM $table ; ";

        /**
         * Ordenar Datos sin limites
         */
        if ($orderBy != null && $orderMode != null && $startAt == null && $endAt == null) {
            $sql = "SELECT $select FROM $relArray[0] $innerJoinText ORDER BY $orderBy $orderMode; ";
        }

        /**
         * Ordenar y limitar datos 
         */
        if ($orderBy != null && $orderMode != null && $startAt != null && $endAt != null) {
            $sql = "SELECT $select FROM $relArray[0] $innerJoinText ORDER BY $orderBy $orderMode LIMIT $startAt,$endAt ; ";
        }
        /**
         * Limitar datos sin Ordenar 
         */
        if ($orderBy == null && $orderMode == null && $startAt != null && $endAt != null) {
            $sql = "SELECT $select FROM $relArray[0] $innerJoinText LIMIT $startAt,$endAt ; ";
        }

        $stmt = Connection::connect()->prepare($sql);
        // $stmt->execute();
        try {
            $stmt->execute();        
        } catch (PDOException $Exeption) {
            //throw $th;
            return null;
        }
        return $stmt -> fetchAll(PDO::FETCH_CLASS);
    }else {
        return null;
    }

}

/**
 * Peticiones Get con Filtro con tablas relacionadas
 */
static public function getRelDataFilter($rel, $type, $select,$linkTo, $equalTo,$orderBy,$orderMode,$startAt,$endAt){
    
    /**
     * Organizamos los filtros 
     */
            // $linkTo = "";
            $linkToArray = explode(",",$linkTo);
            // $equalTo = "";
            $equalToArray = explode("_",$equalTo);
            $linkToText= "";
    
            if (count($linkToArray)>1) {
                foreach ($linkToArray as $key => $value) {
                    if ($key > 0) {
                        $linkToText .= " AND " .$value." = :".$value." ";
                    }
                }
            }

            /**
             * organizamos la relaciones 
             */

    $relArray = explode(",",$rel);
    $typeArray = explode(",",$type);
    $innerJoinText= "";

    if (count($relArray)>1) {
        foreach ($relArray as $key => $value) {
            if ($key > 0) {
                $innerJoinText .= " INNER JOIN ".$value." ON ".$relArray[0].".".$typeArray[$key]." = ".$value.".".$typeArray[$key]." ";
            }
        }
    


        // "SELECT $select FROM $relArray[0] INNER JOIN $relArray[1] ON $relArray[0].$typeArray[0] = $relArray[1].$typeArray[1]";
        "SELECT $select FROM $relArray[0] $innerJoinText WHERE $linkToArray[0] = :$linkToArray[0] $linkToText";
        
        /**
         * Sin ordenar y limitar datos
         */
        $sql = "SELECT $select FROM $relArray[0] $innerJoinText ; ";
        // $sql = "SELECT * FROM $table ; ";

        /**
         * Ordenar Datos sin limites
         */
        if ($orderBy != null && $orderMode != null && $startAt == null && $endAt == null) {
            $sql = "SELECT $select FROM $relArray[0] $innerJoinText  WHERE $linkToArray[0] = :$linkToArray[0] $linkToText ORDER BY $orderBy $orderMode; ";
        }

        /**
         * Ordenar y limitar datos 
         */
        if ($orderBy != null && $orderMode != null && $startAt != null && $endAt != null) {
            $sql = "SELECT $select FROM $relArray[0] $innerJoinText WHERE $linkToArray[0] = :$linkToArray[0] $linkToText ORDER BY $orderBy $orderMode LIMIT $startAt,$endAt ; ";
        }
        /**
         * Limitar datos sin Ordenar 
         */
        if ($orderBy == null && $orderMode == null && $startAt != null && $endAt != null) {
            $sql = "SELECT $select FROM $relArray[0] $innerJoinText WHERE $linkToArray[0] = :$linkToArray[0] $linkToText LIMIT $startAt,$endAt ; ";
            
        }

        // echo '<pre>'; print_r($sql); echo '</pre>';
        // return;

        $stmt = Connection::connect()->prepare($sql);
        foreach ($linkToArray as $key => $value) 
        {
            $stmt -> bindParam(":".$value,$equalToArray[$key], PDO::PARAM_STR);    
        }
        try {
            $stmt->execute();        
        } catch (PDOException $Exeption) {
            //throw $th;
            return null;
        }
        return $stmt -> fetchAll(PDO::FETCH_CLASS);
    }else {
        return null;
    }

}

 /**
     * Peticiones GET para el buscador sin relaciones
     */
    static public function getDataSearch($table, $select, $linkTo, $search,$orderBy,$orderMode,$startAt,$endAt){
        /**
         * Organizamos los filtros 
         */
            // $linkTo = "";
            $linkToArray = explode(",",$linkTo);
            // $equalTo = "";
            $searchToArray = explode("_",$search);
            $linkToText= "";
    
            if (count($linkToArray)>1) {
                
                foreach ($linkToArray as $key => $value) {
                            /**
                     * VAlidar Existencia e la table 
                     */
                    if(empty(Connection::getColumnsData($value))){
                        return null;
                    }
                    if ($key > 0) {
                        $linkToText .= " AND " .$value." = :".$value." ";
                    }
                }
            }
        
        
        /**
         * Sin ordenar y limitar datos
         */
        $sql = "SELECT $select FROM $table WHERE  $linkToArray[0] LIKE '%$searchToArray[0]%' $linkToText; ";
        // $sql = "SELECT * FROM $table ; ";

        /**
         * Ordenar Datos sin limites
         */
        if ($orderBy != null && $orderMode != null && $startAt == null && $endAt == null) {
            $sql = "SELECT $select FROM $table WHERE  $linkToArray[0] LIKE '%$searchToArray[0]%' $linkToText ORDER BY $orderBy $orderMode; ";
        }

        /**
         * Ordenar y limitar datos 
         */
        if ($orderBy != null && $orderMode != null && $startAt != null && $endAt != null) {
            $sql = "SELECT $select FROM $table WHERE  $linkToArray[0] LIKE '%$searchToArray[0]%' $linkToText ORDER BY $orderBy $orderMode LIMIT $startAt,$endAt ; ";
        }
        /**
         * Limitar datos sin Ordenar 
         */
        if ($orderBy == null && $orderMode == null && $startAt != null && $endAt != null) {
            $sql = "SELECT $select FROM $table WHERE  $linkToArray[0] LIKE '%$searchToArray[0]%' $linkToText ORDER BY $orderBy $orderMode LIMIT $startAt,$endAt ; ";
        }

        $stmt = Connection::connect()->prepare($sql);
        foreach ($linkToArray as $key => $value) 
        {
            if ($key > 0) {
                $stmt -> bindParam(":".$value,$searchToArray[$key], PDO::PARAM_STR);    
            }
        }
        try {
            $stmt->execute();        
        } catch (PDOException $Exeption) {
            //throw $th;
            return null;
        }
        return $stmt -> fetchAll(PDO::FETCH_CLASS);
    }

/**
 * Peticiones Get para el buscador con tablas relacionadas
 */
static public function getRelDataSearch($rel, $type, $select,$linkTo, $search,$orderBy,$orderMode,$startAt,$endAt){
    
    /**
     * Organizamos los filtros 
     */
            // $linkTo = "";
            $linkToArray = explode(",",$linkTo);
            // $equalTo = "";
            $searchToArray = explode("_",$search);
            $linkToText= "";
    
            if (count($linkToArray)>1) {
                foreach ($linkToArray as $key => $value) {
                            /**
                     * VAlidar Existencia e la table 
                     */
                    if(empty(Connection::getColumnsData($value))){
                        return null;
                    }
                    if ($key > 0) {
                        $linkToText .= " AND " .$value." = :".$value." ";
                    }
                }
            }

            /**
             * organizamos la relaciones 
             */

            $relArray = explode(",",$rel);
            $typeArray = explode(",",$type);
            $innerJoinText= "";

            if (count($relArray)>1) {
                foreach ($relArray as $key => $value) {
                    if ($key > 0) {
                        $innerJoinText .= " INNER JOIN ".$value." ON ".$relArray[0].".".$typeArray[$key]." = ".$value.".".$typeArray[$key]." ";
                    }
                }
            


        // "SELECT $select FROM $relArray[0] INNER JOIN $relArray[1] ON $relArray[0].$typeArray[0] = $relArray[1].$typeArray[1]";
        "SELECT $select FROM $relArray[0] $innerJoinText WHERE $linkToArray[0] = :$linkToArray[0] $linkToText";
        
        /**
         * Sin ordenar y limitar datos
         */
        $sql = "SELECT $select FROM $relArray[0] $innerJoinText WHERE $linkToArray[0] LIKE '%$searchToArray[0]%' $linkToText; ";
        // $sql = "SELECT * FROM $table ; ";

        /**
         * Ordenar Datos sin limites
         */
        if ($orderBy != null && $orderMode != null && $startAt == null && $endAt == null) {
            $sql = "SELECT $select FROM $relArray[0] $innerJoinText  WHERE $linkToArray[0] LIKE '%$searchToArray[0]%' $linkToText ORDER BY $orderBy $orderMode; ";
        }

        /**
         * Ordenar y limitar datos 
         */
        if ($orderBy != null && $orderMode != null && $startAt != null && $endAt != null) {
            $sql = "SELECT $select FROM $relArray[0] $innerJoinText WHERE $linkToArray[0] LIKE '%$searchToArray[0]%' $linkToText ORDER BY $orderBy $orderMode LIMIT $startAt,$endAt ; ";
        }
        /**
         * Limitar datos sin Ordenar 
         */
        if ($orderBy == null && $orderMode == null && $startAt != null && $endAt != null) {
            $sql = "SELECT $select FROM $relArray[0] $innerJoinText WHERE $linkToArray[0] LIKE '%$searchToArray[0]%' $linkToText LIMIT $startAt,$endAt ; ";
            
        }

        // echo '<pre>'; print_r($sql); echo '</pre>';
        // return;

        $stmt = Connection::connect()->prepare($sql);
        foreach ($linkToArray as $key => $value) 
        {
            if ($key > 0) {
                $stmt -> bindParam(":".$value,$searchToArray[$key], PDO::PARAM_STR);    
            }
        }
        try {
            $stmt->execute();        
        } catch (PDOException $Exeption) {
            //throw $th;
            return null;
        }
        return $stmt -> fetchAll(PDO::FETCH_CLASS);
    }else {
        return null;
    }

}    
       


}