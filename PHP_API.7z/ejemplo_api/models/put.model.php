<?php

require_once "connection.php";
require_once "get.model.php";
class PutModel{
    /**
     * Peticion Post para crear datos de forma dinamica
     */
    static public function putData($table, $data, $id, $nameId){
        // echo '<pre>'; print_r($nameId); echo '</pre>';
        // echo '<pre>'; print_r($id); echo '</pre>';
        // echo '<pre>'; print_r($data); echo '</pre>';
        // echo '<pre>'; print_r($table); echo '</pre>';


        /**
         * validar el ID
         */
        $resposne = GetModel::getDataFilter($table, $nameId, $nameId, $id, null, null, null, null);

        if (empty($resposne)) {
           
           /**
            * para que aparesca error 400  se debe devolver null
            */
            // $resposne = array(
            //     "comment" => "Error: the Id is not  in the database"
            // );

            // return $resposne;

            return null;
        }

        $set ="";

        foreach ($data as $key => $value) {
           $set .= $key." = :".$key.",";
           
        }
        $set = substr($set, 0, -1);

        // echo '<pre>'; print_r($set); echo '</pre>';
        // return;
        $sql = "UPDATE $table
        SET $set
        WHERE $nameId = :$nameId ;";

        $link = Connection::connect();
        $stmt = $link->prepare($sql);

        foreach ($data as $key => $value) {
            $stmt->bindParam(":".$key, $data[$key], PDO::PARAM_STR);
        }
        $stmt->bindParam(":".$nameId, $id, PDO::PARAM_STR);
        
        if ($stmt -> execute()) {
            $resposne = array(
                "comment" => "The process waas sucessfull"
            );

            return $resposne;
        }else {
            return $link->errorInfo();
        }

    }
}