<?php

require_once "connection.php";
class PostModel{
    /**
     * Peticion Post para crear datos de forma dinamica
     */
    static public function postData($table, $data){
        // echo '<pre>'; print_r($data); echo '</pre>';
        // echo '<pre>'; print_r($table); echo '</pre>';

        $colums = "";
        $params = "";
        foreach ($data as $key => $value) {
            $colums .= $key.",";
            $params .= ":".$key.",";
        }

        $colums = substr($colums, 0, -1);
        $params = substr($params, 0, -1);
        
        // $sql = " INSERT INTO $table
        // (
        // `nombre_users`,
        // `apellidos_users`,
        // `usuario_users`,
        // `clave_users`,
        // `fecha_crear`,
        // `cedula_users`,
        // `email_users`,
        // `estado_users`)
        // VALUES
        // (
        // `:nombre_users`,
        // `:apellidos_users`,
        // `:usuario_users`,
        // `:clave_users`,
        // `:fecha_crear`,
        // `:cedula_users`,
        // `:email_users`,
        // `:estado_users);
        //  ";

        $sql = " INSERT INTO $table
        ($colums) VALUES ($params);";

        $link = Connection::connect();
        $stmt = $link->prepare($sql);
        

        foreach ($data as $key => $value) {
            $stmt->bindParam(":".$key, $data[$key], PDO::PARAM_STR);
        }
        // $stmt -> execute();
        if ($stmt -> execute()) {
            $resposne = array(
                "lastId" => $link->lastInsertId(),
                "comment" => "The process waas sucessfull"
            );

            return $resposne;
        }else {
            return $link->errorInfo();
        }

    }
}