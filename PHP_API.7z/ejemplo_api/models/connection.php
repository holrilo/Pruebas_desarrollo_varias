<?php
require_once "get.model.php";
// require_once "vendor/autoload.php";
// use Firebase\JWT\JWT;


class Connection{
    /**
     * Informacion de la BD
     */

     static public function infoDatabase(){

        $infoDB = array(
            "database" => "pruebas_api",
            "user" => "root",
            "pass" => ""
        );

        return $infoDB;
    }

     /**
      * Conexion a la base de datos
      */

      static public function connect(){

        try {
            $link = new PDO(
                "mysql:host=localhost;dbname=". Connection::infoDatabase()["database"],
                Connection::infoDatabase()["user"],
                Connection::infoDatabase()["pass"]
            );
            //nos indica que convierta caracteres a español latino 
            $link->exec("set names utf8");

        // } catch (\Throwable $th) {
        } catch (PDOException $e) {
            //throw $th;
            die("Error: " .$e->getMessage());
        }

        return $link;

      }


      /**
       * Validar Existencia de una tabla en la BD
       */

      static public function getColumnsData($table, $colums){
        /**
         * Traer el nombre de la base de datos 
         */
        $database = Connection::infoDatabase()["database"];
        // return Connection::connect()
        // ->query("SELECT  COLUMN_NAME AS item FROM information_schema.columns WHERE table_schema = '$database' AND table_name = '$table'; " )
        // ->fetchAll(PDO::FETCH_OBJ);

        /**
         * Validamos las columnas de una tabla 
         */
        $validate = Connection::connect()
        ->query("SELECT  COLUMN_NAME AS item FROM information_schema.columns WHERE table_schema = '$database' AND table_name = '$table'; " )
        ->fetchAll(PDO::FETCH_OBJ);


        /**
         * validamos existencia de la tabla 
         */
        if (empty( $validate )) {
            return null;
        }else {

            /**
             * Ajuste a solicitud de columnas globales 
             */

            if ($colums[0] == "*") {
                array_shift($colums);
            }


            /**
             * Validamos existencia de columnas 
             * 
             */
            $sum = 0;
            foreach ($validate as $key => $value) {
                // in_array($value->item, $colums);
                // echo '<pre>'; print_r(in_array($value->item, $colums)); echo '</pre>';

                $sum += in_array($value->item, $colums);
                

                // echo '<pre>'; print_r($value->item); echo '</pre>';
                # code...
            }
            // echo '<pre>'; print_r($sum); echo '</pre>';

            // count($colums);
            // echo '<pre>'; print_r(count($colums)); echo '</pre>';

            return $sum == count($colums) ? $validate : null;
        }
      }


     /**
      * Generar Token de  autenticacion 
      */

      static public function jwt($id, $email){
        // return $id;

        $time = time();

        $token =  array(
            
            "iat" => $time,  // Tiempo en que inicia el token 
            "exp" => $time + (60*60*24), //Tiempo en que expira el token (1 dia)
            "data" => [

                "id" => $id,
                "email" => $email
            ]
        );

        // $jwt = JWT::encode($token," a6s54d6a5sd6sda5as4d56asa654", "HS256"); //el segundo parametro el el KEY
        return $token;
        
      }

       /**
      * Validar el Token de Seguridad 
      */

      static public function tokenValidate($token, $table, $suffix){

        /**
         * traemos el usuairo e acuerdo al token 
         */

        $user = GetModel::getDataFilter($table, "token_exp_".$suffix , "token_".$suffix, $token,null,null,null,null);
        // echo '<pre>'; print_r($user); echo '</pre>';

        // // echo '<pre>'; print_r($token); echo '</pre>';
        // return;

        if (!empty($user)) {
            /**
             * Validamos que el token no haya expirado
             */

             $time = time();

             if ($user[0]->{"token_exp_".$suffix} > $time) {
                return "ok";
             }else {
                return "expired";
             }
        }else {
            return "no-auth";
        }
      }

    /**
      * APIKEY 
      * https://pinetools.com/es/generador-cadenas-aleatorias
      */

      static public function apikey(){

        return "83AX8pSGmndujJ9QMAvNBYhBABUgkQ";
      }

      /**
       * Acceso Publico
       */

    static public function publicAcces(){
        $table = ["usuarios"];

        return $table;
    }

}