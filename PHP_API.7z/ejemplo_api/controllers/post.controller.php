<?php
require_once "models/post.model.php";
require_once "models/get.model.php";
require_once "models/connection.php";

require_once "vendor/autoload.php";
use Firebase\JWT\JWT;

require_once "models/put.model.php";

class PostController{

    /**
     * Peticion POST para crear datos
     */

     static public function postData($table, $data){
        $response = PostModel::postData($table,$data);
      //   echo '<pre>'; print_r($response ); echo '</pre>';
      //   return;
      $return = new PostController();
      $return-> fncResponse($response, null, null);

     }

    /**
     * Peticion POST para Registrar usuario 
     */

     static public function postRegister($table, $data, $suffix){

        // echo '<pre>'; print_r($data["clave_".$suffix]); echo '</pre>';
        // return;

        if (isset($data["clave_".$suffix]) && $data["clave_".$suffix] !=null) {
           
            /**
             * Encryptamos la contraseña
             */
            $crypt = crypt($data["clave_".$suffix], '$2a$07$usesomesillystringforsalt$');
            $data["clave_".$suffix] = $crypt;

            
            $response = PostModel::postData($table,$data); 

            $return = new PostController();
            $return-> fncResponse($response, null,$suffix);

        }else {
            /**
             * registro de usuario desde APP Externa 
             */
            $response = PostModel::postData($table,$data); 

            if (isset($response["comment"]) && $response["comment"] == "The process waas sucessfull") {
                
                /**
                 * validar si el usuario existe en BD
                 */
                $resposne = GetModel::getDataFilter($table, "*", "email_".$suffix , $data["email_".$suffix], null, null, null, null);
        
                if (!empty($resposne)) {


                    $token = Connection::jwt($resposne[0]->{"id_".$suffix},$resposne[0]->{"email_".$suffix});
                    // echo '<pre>'; print_r($token); echo '</pre>';
                    // return;

                    $jwt = JWT::encode($token," a6s54d6a5sd6sda5as4d56asa654", "HS256"); //el segundo parametro el el KEY
                    /**
                     * aCTUALIZAMOS LA BASE DE DATOS CON EL TOKEN DEL USUARIO 
                     */

                    $data = array(
                        "token_".$suffix => $jwt,
                        "token_exp_".$suffix =>$token["exp"]
                    );

                    $update = PutModel::putData($table, $data, $resposne[0]->{"id_".$suffix}, "id_".$suffix);
                    //  echo '<pre>'; print_r($update); echo '</pre>';
                    // return;

                    if (isset($update["comment"]) && $update["comment"] == "The process waas sucessfull") {
                        
                        $resposne[0]->{"token_".$suffix} = $jwt;
                        $resposne[0]->{"token_exp_".$suffix} = $token["exp"];

                        $return = new PostController();
                        $return-> fncResponse($resposne, null,$suffix);
                    }
                }

            }

        }


    //     $response = PostModel::postData($table,$data);
    //   //   echo '<pre>'; print_r($response ); echo '</pre>';
    //   //   return;
    //   $return = new PostController();
    //   $return-> fncResponse($response);

     }


      /**
     * Peticion POST para Login usuario 
     */
     /**
      * composer require firabase/php-jwt
      */
     static public function postLogin($table, $data, $suffix){

         /**
         * validar si el usuario existe en BD
         */
        $resposne = GetModel::getDataFilter($table, "*", "email_".$suffix , $data["email_".$suffix], null, null, null, null);
 
        if (!empty($resposne)) {
            
            if($resposne[0]->{"clave_".$suffix} != null){

                /**
                 * Encryptamos la contraseña
                 */
                $crypt = crypt($data["clave_".$suffix], '$2a$07$usesomesillystringforsalt$');
                // echo '<pre>'; print_r($resposne->{"clave_".$suffix}); echo '</pre>';
                
                if ($resposne[0]->{"clave_".$suffix} == $crypt) {
                    
                    $token = Connection::jwt($resposne[0]->{"id_".$suffix},$resposne[0]->{"email_".$suffix});
                    // echo '<pre>'; print_r($token); echo '</pre>';
                    // return;

                    $jwt = JWT::encode($token," a6s54d6a5sd6sda5as4d56asa654", "HS256"); //el segundo parametro el el KEY
                    /**
                     * aCTUALIZAMOS LA BASE DE DATOS CON EL TOKEN DEL USUARIO 
                     */

                    $data = array(
                        "token_".$suffix => $jwt,
                        "token_exp_".$suffix =>$token["exp"]
                    );

                    $update = PutModel::putData($table, $data, $resposne[0]->{"id_".$suffix}, "id_".$suffix);
                    //  echo '<pre>'; print_r($update); echo '</pre>';
                    // return;

                    if (isset($update["comment"]) && $update["comment"] == "The process waas sucessfull") {
                        
                        $resposne[0]->{"token_".$suffix} = $jwt;
                        $resposne[0]->{"token_exp_".$suffix} = $token["exp"];

                        $return = new PostController();
                        $return-> fncResponse($resposne, null,$suffix);
                    }
                
                }else {
                    $response = null;
                    $return = new PostController();
                    $return-> fncResponse($response,"Wrong password",$suffix);
                }
            }else {
                                    /**
                     * aCTUALIZAMOS EL TOKEN PARA USARIOS LOGEADSO DESDE APP EXTERNAS
                     */
                $token = Connection::jwt($resposne[0]->{"id_".$suffix},$resposne[0]->{"email_".$suffix});
                    // echo '<pre>'; print_r($token); echo '</pre>';
                    // return;

                    $jwt = JWT::encode($token," a6s54d6a5sd6sda5as4d56asa654", "HS256"); //el segundo parametro el el KEY


                    $data = array(
                        "token_".$suffix => $jwt,
                        "token_exp_".$suffix =>$token["exp"]
                    );

                    $update = PutModel::putData($table, $data, $resposne[0]->{"id_".$suffix}, "id_".$suffix);
                    //  echo '<pre>'; print_r($update); echo '</pre>';
                    // return;

                    if (isset($update["comment"]) && $update["comment"] == "The process waas sucessfull") {
                        
                        $resposne[0]->{"token_".$suffix} = $jwt;
                        $resposne[0]->{"token_exp_".$suffix} = $token["exp"];

                        $return = new PostController();
                        $return-> fncResponse($resposne, null,$suffix);
                    }
            }
            
        }else{
            $response = null;
            $return = new PostController();
            $return-> fncResponse($response,"Wrong email",$suffix);
        }
       

     }
         /**
     * Respuesta del controlador 
     */

     public function fncResponse($response, $error,$suffix){
        
      if(!empty($response)){
        /**
         * Quitamos la contraseña de la respuesta 
         */
        if (isset($response[0]->{"clave_".$suffix})) {
            unset($response[0]->{"clave_".$suffix});
        }

          $json = array(
              'status' => 200,
            //   'total' => count($response),
              'results' => $response
          );
      }else{
        if ($error != null) {
            $json = array(
                'status' => 404,
                'results' => $error
            );
        }else{
            $json = array(
                'status' => 404,
                'results' => 'Not found',
                'method' => 'post'
            );
        }

      }


      
      echo json_encode($json, http_response_code($json["status"])); 
   }
}