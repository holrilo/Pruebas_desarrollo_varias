<?php
class RoutesController{
    public function index(){
        include "Routes/routes.php";
    }
}

?>