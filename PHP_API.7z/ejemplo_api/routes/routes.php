<?php

require_once "models/connection.php";
require_once "controllers/get.controller.php";
// echo "Hola Soy API";

// $_SERVER['REQUEST_URI'];
// ECHO '<pre>';  print_r($_SERVER['REQUEST_URI']); echo "</pre>";

$routesArray = explode("/",$_SERVER['REQUEST_URI']);
$routesArray = array_filter($routesArray);

// ECHO '<pre>';  print_r($routesArray); echo "</pre>";

/**
 * 
 * Cuando no se hace ninguna peticion a la API
 * 
 */

if (count($routesArray) == 0) {

    # 404 es dato no encontrado
    $json = array(
        'status' => 404,
        'result' => 'Not found'
    );
    
    echo json_encode($json, http_response_code($json["status"]));
    
    return;
}


/**
 * 
 * Cuando si se hace ninguna peticion a la API
 * 
 */

if (count($routesArray)==1 && isset($_SERVER['REQUEST_METHOD'])) {
    # code...
    // echo '<pre>'; print_r($_SERVER['REQUEST_METHOD']); echo '</pre>';

    $table = explode("?",$routesArray[1])[0];

    /**
     * Validar llave Secreta APIKEY
     */
    
            // getallheaders();
            // echo '<pre>'; print_r(getallheaders()["Authorization"]); echo '</pre>';

            // Connection::apikey();
            
            // echo '<pre>'; print_r(Connection::apikey()); echo '</pre>';

    if (!isset(getallheaders()["Authorization"]) || getallheaders()["Authorization"] != Connection::apikey()) {

        if (in_array($table, Connection::publicAcces()) == 0) {
            $json = array(
                'status' => 400,
                'result' => "You are not authorized to maje this request"
            );
    
            echo json_encode($json, http_response_code($json["status"]));
    
            return;
        }else {
            /**
             * Acceso publico
             */

             $response = new GetController();
             $response -> getData($table, "*",null,null,null,null);  
             return;
        }


    }

    


    /**
     * Peticiones GET
     */
    if ($_SERVER['REQUEST_METHOD']== "GET") {
        include  "services/get.php";
    }
    
    /**
     * Peticiones POST
     */
    if ($_SERVER['REQUEST_METHOD']== "POST") {
        include  "services/post.php";

        // $json = array(
        //     'status' => 200,
        //     'result' => 'Solicitud POST'
        // );
        
        // echo json_encode($json, http_response_code($json["status"]));    
    }

    /**
     * Peticiones PUT
     */
    if ($_SERVER['REQUEST_METHOD']== "PUT") {

        include  "services/put.php";

        // $json = array(
        //     'status' => 200,
        //     'result' => 'Solicitud PUT'
        // );
        
        // echo json_encode($json, http_response_code($json["status"]));    
    }

    /**
     * Peticiones DELETE
     */
    if ($_SERVER['REQUEST_METHOD']== "DELETE") {

        include  "services/delete.php";
        // $json = array(
        //     'status' => 200,
        //     'result' => 'Solicitud DELETE'
        // );
        
        // echo json_encode($json, http_response_code($json["status"]));    
    }
}



// return ;

// $json = array(
// 	'status' => 200,
// 	'result' => 'success'
// );

// echo json_encode($json);

// return;


?>