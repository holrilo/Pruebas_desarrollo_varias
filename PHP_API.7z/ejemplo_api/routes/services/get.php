<?php

require_once "controllers/get.controller.php";

// $table = $routesArray[1];
$table = explode("?",$routesArray[1])[0];
// echo '<pre>'; print_r($table); echo '</pre>';
// return;

$select = $_GET["select"] ?? "*"; // operador de comparacion  es ??
$orderBy = $_GET["orderBy"] ?? null;
$orderMode = $_GET["orderMode"] ?? null;
$startAt = $_GET["startAt"] ?? null;
$endAt = $_GET["endAt"] ?? null;


$response = new GetController();
/**
 * Peticiones Get Con Filtro 
 */
if (isset($_GET["linkTo"]) && isset($_GET["equalTo"]) && !isset($_GET["rel"]) && !isset($_GET["type"])) {
    $response -> getDataFilter($table, $select,$_GET["linkTo"],$_GET["equalTo"],$orderBy,$orderMode,$startAt,$endAt);

    /**
     * Peticiones GET sin filtro  entre tablas relacionadas 
     */

}elseif (isset($_GET["rel"]) && isset($_GET["type"]) && $table == "usuarios" && !isset($_GET["linkTo"]) && !isset($_GET["equalTo"])) {
    $response -> getRelData($_GET["rel"],$_GET["type"], $select,$orderBy,$orderMode,$startAt,$endAt);    

    /**
     * Peticiones GET con filtro  entre tablas relacionadas 
     */

}elseif (isset($_GET["rel"]) && isset($_GET["type"]) && $table == "usuarios" && isset($_GET["linkTo"]) && isset($_GET["equalTo"])) {
    $response -> getRelDataFilter($_GET["rel"],$_GET["type"], $select,$_GET["linkTo"],$_GET["equalTo"],$orderBy,$orderMode,$startAt,$endAt);    

        /**
     * Peticiones GET para el buscador  
     */
}elseif(isset($_GET["linkTo"]) && isset($_GET["search"]) && !isset($_GET["rel"]) && !isset($_GET["type"])){
    $response -> getDataSearch($table, $select,$_GET["linkTo"],$_GET["search"],$orderBy,$orderMode,$startAt,$endAt);

        /**
     * Peticiones GET para el buscador  con relaciones
     */
}elseif(isset($_GET["rel"]) && isset($_GET["type"]) && $table == "usuarios" && isset($_GET["linkTo"]) && isset($_GET["search"])){
    $response -> getRelDataSearch($_GET["rel"],$_GET["type"], $select,$_GET["linkTo"],$_GET["search"],$orderBy,$orderMode,$startAt,$endAt);    

}else {
    /**
     * Peticiones GET sin filtro 
     */
    $response -> getData($table, $select,$orderBy,$orderMode,$startAt,$endAt);    
}




// $response = GetController::getData($table);
// echo '<pre>'; print_r($response); echo '</pre>';

// return;

