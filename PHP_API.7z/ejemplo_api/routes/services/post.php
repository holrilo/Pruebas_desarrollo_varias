<?php
require_once "models/connection.php";
require_once "controllers/post.controller.php";

if (isset($_POST)) {

    $colums = array();
    

    foreach (array_keys($_POST) as $key => $value) {
        // echo '<pre>'; print_r($value); echo '</pre>';
        # code...

        array_push($colums, $value);
    }

    // echo '<pre>'; print_r($colums); echo '</pre>';

    // Connection::getColumnsData($table, $colums);
    // echo '<pre>'; print_r(Connection::getColumnsData($table, $colums)); echo '</pre>';
    // echo '<pre>'; print_r($_POST); echo '</pre>';
    # code...


    /**
     * Validar la Tabla y las columnas si existen 
     * 
     */
    if (empty(Connection::getColumnsData($table, $colums))) {

        $json = array(
            'status' => 400,
            'result' => "Error: Fields n the form do not match the database"
        );
        
        echo json_encode($json, http_response_code($json["status"]));    

        return;
    }
    
    
    $response = new PostController();
    /**
     * Peticion posT para el registro de usuario
     */

    if (isset($_GET["register"]) && $_GET["register"] == true) {
        $suffix = $_GET["suffix"] ?? "users";
        $response->postRegister($table,$_POST,$suffix);

    /**
     * Peticion posT login de usuario
     */
    }elseif (isset($_GET["login"]) && $_GET["login"] == true) {
            $suffix = $_GET["suffix"] ?? "users";
            $response->postLogin($table,$_POST,$suffix);
    }else{
        /**
         * Peticion posT para usuarios autorizados
         */
        if (isset($_GET["token"])) {
            
            if ($_GET["token"]  == "no" && isset($_GET["exept"])) {
                
                /**
                 * Validar la Tabla y las columnas si existen 
                 * 
                 */

                $colums = array($_GET["exept"]);

                if (empty(Connection::getColumnsData($table, $colums))) {

                    $json = array(
                        'status' => 400,
                        'result' => "Error: Fields n the form do not match the database"
                    );
                    
                    echo json_encode($json, http_response_code($json["status"]));    

                    return;
                }
                    /**
                    * Solicitamos respuesta del controlador para crear datos en cualquier tabla 
                    */
                    
                    $response->postData($table,$_POST);

            }else{

                $table = $_GET["table"] ?? "users";
                $suffix = $_GET["suffix"] ?? "users";

                $validate = Connection::tokenValidate($_GET["token"], $table, $suffix);


                /**  */
                if ($validate == "ok") {
                    /**
                     * Solicitamos respuesta del controlador para crear datos en cualquier tabla 
                     */
                    
                    $response->postData($table,$_POST);
                }

                /**
                 * Error cuando el token a expirado
                 * 
                 * https://www.epochconverter.com/
                 */
                
                if ($validate == "expired"){
                    $json = array(
                        'status' => 303,
                        'result' => "Error: The token has expired"
                    );
                    
                    echo json_encode($json, http_response_code($json["status"]));    
            
                    return;
                }

                /**
                 * error cuando el token  no coincide en BD
                 */

                if ($validate == "no-auth"){
                    $json = array(
                        'status' => 400,
                        'result' => "Error: The user is not autorized"
                    );
                    
                    echo json_encode($json, http_response_code($json["status"]));    
            
                    return;
                }
            }
            /**
             * Error cuendo no envia el token
             */
        }else{
            $json = array(
                'status' => 400,
                'result' => "Error: Autorization required"
            );
            
            echo json_encode($json, http_response_code($json["status"]));    
    
            return;
            
        }




    }




}