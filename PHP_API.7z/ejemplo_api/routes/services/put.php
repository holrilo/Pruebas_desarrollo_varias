<?php
require_once "models/connection.php";
require_once "controllers/put.controller.php";

if (isset($_GET["id"]) && isset($_GET["nameId"])) {
    /**
     * Capturamos datos del formulaido 
     */

     $data = array();
     
     file_get_contents('php://input');
    //  echo '<pre>'; print_r(file_get_contents('php://input')); echo '</pre>';
    /**
     * convierte en arreglo 
     */
    parse_str(file_get_contents('php://input'),$data);
    $colums = array();
    foreach (array_keys($data) as $key => $value) {
        // echo '<pre>'; print_r($value); echo '</pre>';
        # code...

        array_push($colums, $value);
        
    }

    array_push($colums, $_GET["nameId"]);
    $colums = array_unique($colums);
     /**
     * Validar la Tabla y las columnas si existen 
     * 
     */
    if (empty(Connection::getColumnsData($table, $colums))) {

        $json = array(
            'status' => 400,
            'result' => "Error: Fields n the form do not match the database"
        );
        
        echo json_encode($json, http_response_code($json["status"]));    

        return;
    }

         /**
         * Peticion PUT para usuarios autorizados
         */
        if (isset($_GET["token"])) {

            /**
             * Put para usuarios NO autorizados 
             */
            if ($_GET["token"]  == "no" && isset($_GET["exept"])) {
                
                /**
                 * Validar la Tabla y las columnas si existen 
                 * 
                 */

                $colums = array($_GET["exept"]);

                if (empty(Connection::getColumnsData($table, $colums))) {

                    $json = array(
                        'status' => 400,
                        'result' => "Error: Fields n the form do not match the database"
                    );
                    
                    echo json_encode($json, http_response_code($json["status"]));    

                    return;
                }
                /**
                 * Solicitamos respuesta del controlador para editar datos en cualquier tabla 
                 */
                $response = new PutController();
                $response->putData($table,$data,$_GET["id"],$_GET["nameId"]);


            /**
             * Put para usuarios autorizados 
             */
            }else{

                $table = $_GET["table"] ?? "users";
                $suffix = $_GET["suffix"] ?? "users";

                $validate = Connection::tokenValidate($_GET["token"], $table, $suffix);


                /**  */
                if ($validate == "ok") {
                /**
                 * Solicitamos respuesta del controlador para editar datos en cualquier tabla 
                 */
                $response = new PutController();
                $response->putData($table,$data,$_GET["id"],$_GET["nameId"]);

                // echo '<pre>'; print_r($data); echo '</pre>';
                }

                /**
                 * Error cuando el token a expirado
                 * 
                 * https://www.epochconverter.com/
                 */
                
                if ($validate == "expired"){
                    $json = array(
                        'status' => 303,
                        'result' => "Error: The token has expired"
                    );
                    
                    echo json_encode($json, http_response_code($json["status"]));    
            
                    return;
                }

                /**
                 * error cuando el token  no coincide en BD
                 */

                if ($validate == "no-auth"){
                    $json = array(
                        'status' => 400,
                        'result' => "Error: The user is not autorized"
                    );
                    
                    echo json_encode($json, http_response_code($json["status"]));    
            
                    return;
                }
            }
        /**
         * Error cuendo no envia el token
         */
        }else{
            $json = array(
                'status' => 400,
                'result' => "Error: Autorization required"
            );
            
            echo json_encode($json, http_response_code($json["status"]));    
    
            return;
            
        }
}