<?php

/**
 * Mostroar Errores
 */
//visualizar errores desde el naegador o postman
ini_set('display_errors',1);
// permita crear el arrchivo dentro de la carpeta del proyeto 
ini_set("log_erros",1);
// ubicacion dende se guaradar el log 
ini_set("error_log","C:/xampp/htdocs/ejemplo_api/php_error_log");

/**
 * CORS
 */

header('Access-Control-Allow-Origin: *');
// header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
header("Allow: GET, POST, OPTIONS, PUT, DELETE");
header("Content-Type: application/json; charset=UTF-8");

/**
 * Requerimientos
 */

// require_once "models/connection.php";

// // Connection::infoDatabase()
// echo '<pre>'; print_r(Connection::connect()); echo '</pre>';

// return;

require_once "controllers/routes.controller.php";

$index = new routesController();
$index -> index();
?>
